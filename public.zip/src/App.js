import './App.css';
import './Appmobile.css';
import AppRouter from './containers/Router';
function App() {
  return (
   <>
   <AppRouter />
   </>
  );
}

export default App;
