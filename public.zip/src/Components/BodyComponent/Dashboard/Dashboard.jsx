import {React,useState} from "react";

export default function Dashboard() {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectedFiles1, setSelectedFiles1] = useState([]);
  const [selectedFiles2, setSelectedFiles2] = useState([]);
  const [selectedFiles3, setSelectedFiles3] = useState([]);

  const handleImageChange = (e) => {
    // console.log(e.target.files[])
    if (e.target.files) {
      const filesArray = Array.from(e.target.files).map((file) => URL.createObjectURL(file));

      // console.log("filesArray: ", filesArray);

      setSelectedFiles((prevImages) => prevImages.concat(filesArray));
      Array.from(e.target.files).map(
        (file) => URL.revokeObjectURL(file) // avoid memory leak
      );

    }
  };


  const renderPhotos = (source) => {
    console.log('source: ', source);
    return source.map((photo) => {
      return <img src={photo} alt="" key={photo} />;
    });
  };


  function hide() {
    // let main = document.querySelector('.form');
    // main.style.display = 'none';
    // let hide = document.querySelector('.hide');
    // hide.style.display = 'block';
  }
  return (<>
    <div className="app">

      <div className="form">
        <h3 className="Thead">Profile Picture</h3>
        <input type="file" id="file" accept="image/*" multiple onChange={handleImageChange} />
        <div className="label-holder">
          <label htmlFor="file" className="label">
            <i className="material-icons">add_a_photo</i>
          </label>
        </div>
        <div className="result">{renderPhotos(selectedFiles)}</div>
        <button onClick={hide} className="mybtn">Next</button>
      </div>

      <div className="form">
        <h3 className="Thead">Driver License<br></br>(Front side and back side)</h3>
        <input type="file" id="file" accept="image/*" multiple onChange={handleImageChange} />
        <div className="label-holder">
          <label htmlFor="file" className="label">
            <i className="material-icons">add_a_photo</i>
          </label>
        </div>
        <div className="result">{renderPhotos(selectedFiles1)}</div>
        <button onClick={hide} className="mybtn">Next</button>
      </div>




      <div className="form">
        <h3 className="Thead">Driver Accreditation</h3>
        <input type="file" id="file" accept="image/*" multiple onChange={handleImageChange} />
        <div className="label-holder">
          <label htmlFor="file" className="label">
            <i className="material-icons">add_a_photo</i>
          </label>
        </div>
        <div className="result">{renderPhotos(selectedFiles2)}</div>
        <button onClick={hide} className="mybtn">Next</button>
      </div>

      <div className="form">
        <h3 className="Thead">Driver Accreditation</h3>
        <input type="file" id="file" accept="image/*" multiple onChange={handleImageChange} />
        <div className="label-holder">
          <label htmlFor="file" className="label">
            <i className="material-icons">add_a_photo</i>
          </label>
        </div>
        <div className="result">{renderPhotos(selectedFiles3)}</div>
        <button onClick={hide} className="mybtn">Next</button>
      </div>

      <div className="hide">
        <h1>Wait For Approval</h1>
      </div>
      </div>
      <div>

    </div>
  </>
  )
}
