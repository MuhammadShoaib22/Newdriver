import React from "react";

export default function Link() {
  return (
    <>
    <h1>Payment information</h1>
    </>
  )
}
