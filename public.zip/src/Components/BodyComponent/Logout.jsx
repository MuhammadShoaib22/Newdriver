import React from "react";

export default function Logout() {
  return (
    <div>
      <h1>Logout component</h1>
    </div>
  );
}
