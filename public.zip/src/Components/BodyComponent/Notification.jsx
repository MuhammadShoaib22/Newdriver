import React from "react";

export default function Notification() {
  return (
    <div>
      <h1>Notification</h1>
    </div>
  );
}
