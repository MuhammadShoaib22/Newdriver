import { BrowserRouter } from "react-router-dom";
import "../App.css";
import HeaderComponent from "./Header/HeaderComponent";
import FooterComponent from "./FooterComponent";

function Dashboard(){
    return(<>
        <BrowserRouter>
      <HeaderComponent />
      <FooterComponent />
    </BrowserRouter>
    </>)    
}



export default Dashboard;