import Bgform from '../assests/car-02.svg';
import { React, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLock, faUser } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import fire from '../fire'

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const clearErrors = () =>{
        setEmailError('');
        setPasswordError('');   
      }

    const handleLogin = () => {
        clearErrors()
        fire.auth()
            .signInWithEmailAndPassword(email, password)
            .catch(err => {
                switch (err.code) {
                    case "auth/invalid-email":
                    case "auth/user-disabled":
                    case "auth/user-not-found":
                        setEmailError(err.message);
                        break;
                    case "auth/wrong-password":
                        setPasswordError(err.message);
                        break;
                }
            });
    };
    return (<>
        <div className="Form1con">
            <div className="Form1">
                <img src={Bgform} alt="Helloworld" className="Bgimg" />
            </div>

            <div className="Form2">

                <div className="Formhead">
                    <h1>Sign In</h1>
                </div>
                <div className="Formbody">
                    <FontAwesomeIcon icon={faUser} />
                    <input type="email" placeholder="Please enter your email" required className="inputlogin" /><br />
                    <FontAwesomeIcon icon={faLock} />
                    <input type="password" placeholder="Please enter your password" className="inputlogin" />
                    <p style={{ textAlign: "right", cursor: "pointer" }}>Forgot password ?</p>
                </div>

                <div className="Formfooter">
                    <Link to="/Dashboard">
                        <button className="formbtn" onClick={handleLogin}>Sign In</button>
                    </Link>
                    <Link to="/Otp">
                        <button className="formbtn">Don't Have Account</button>
                    </Link>
                </div>

            </div>
        </div>
    </>)
}



export default Login;