import React, { Component } from 'react';
import firebaseConfig from '../firebaseConfig';
import * as firebaseui from 'firebaseui';
import firebase from 'firebase';
import 'firebaseui/dist/firebaseui.css';
class Otp extends Component {
  componentDidMount() {
    !firebase.apps.length ? firebase.initializeApp(firebaseConfig) : firebase.app()
    const uiConfig = {
      signInOptions: [{
        provider: firebase.auth.PhoneAuthProvider.PROVIDER_ID,
        recaptchaParameters: {
          type: 'image',
          size: 'normal',
          badge: 'bottomleft',
          Hostname:"localhost"
        },
        defaultCountry: 'AU'
      }],
      callbacks: {
        signInSuccessWithAuthResult: function(authResult, redirectUrl){
          alert('successful');
          return true;
        }
      },
      signInSuccessUrl : "/Signup"
    };

    var ui = new firebaseui.auth.AuthUI(firebase.auth());
    ui.start("#firebaseui-auth-container", uiConfig);

  };
  render() {
    return (
        <>
        <div className="Main"></div>
      <div id='firebaseui-auth-container'>
      </div>
        </>
        
    );
  }
}

export default Otp;