import Logo from '../assests/logo.png';
import { Link } from 'react-router-dom';
import fire from '../fire';
import React, { useState, useEffect } from 'react';



function Signup() {

  const [user, setUser] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [hasAccount, setHasAccount] = useState('false');


  const clearInput = () => {
    setEmail('');
    setPassword('');
  }

  const clearErrors = () => {
    setEmailError('');
    setPasswordError('');
  }


  const handleSignup = () => {
    clearErrors()
    fire.auth().createUserWithEmailAndPassword(email, password)
      .then((res) => {
        alert("User signup successfully")
        window.location('/dashboard')
      })
      .catch((err) => {
        console.log(err.message)
      })
  }




  const handleLogout = () => {
    fire.auth().signOut();
  }

  const authListener = () => {
    fire.auth()
      .onAuthStateChanged((user) => {
        if (user) {
          clearInput()
          setUser(user);
        } else {
          setUser("");
        }
      });
  };

  useEffect(() => {
    authListener();
  }, [])
  return (<>
    <div className="Signupmain">
      <div className="SingUpHead">
        <img src={Logo} alt="KangarooLogo" className="Logo" />
        <h3>Sign up With Kangaroo</h3>
      </div>
      <div className="singupbody">
        <input type="email" placeholder="Please Enter your email" required className="inputlogin" onChange={(e) => setEmail(e.target.value)} /><br />
        <input type="password" placeholder="Please Enter your password" className="inputlogin" onChange={(e) => setPassword(e.target.value)} /><br />
      </div>
      <div className="terms">
        <input type="checkbox" /><p>I accept Terms of Use & Privacy Policy</p>
      </div>
      <div className="Formfooter">
        <Link to="/">
          <button className="formbtn">Have an account?</button>
        </Link>
          <button className="formbtn" onClick={handleSignup}>Sign up</button>
      </div>
    </div>
  </>)
}

export default Signup;