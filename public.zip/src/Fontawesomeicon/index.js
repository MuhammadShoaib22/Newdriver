import { library } from '@fortawesome/fontawesome-svg-core'
import { faUser, faLock , faArrowAltCircleLeft } from '@fortawesome/free-solid-svg-icons'

library.add(faUser, faLock,faArrowAltCircleLeft)