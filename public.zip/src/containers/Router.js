import { BrowserRouter as Router,Route,Switch } from "react-router-dom"
import Login from "../Components/Login"
import Otp from "../Components/Otp"
import Dashboard from "../Components/Dashboard"
import Signup from "../Components/Signup"

function AppRouter(){
    return (
        <Router>
            <Switch>
                <Route exact path="/" component={Login}/>
                <Route exact path="/Dashboard" component={Dashboard}/>
                <Route exact path="/Otp" component={Otp}/>
                <Route exact path="/Signup" component={Signup}/>
            </Switch>
        </Router>
    )
}

export default AppRouter;