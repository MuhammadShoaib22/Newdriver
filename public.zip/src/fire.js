import firebase from 'firebase';

var firebaseConfig = {
    apiKey: "AIzaSyCoGQo_iHKn2g6zAVvsohnTsLBZfiZYSOw",
    authDomain: "phonenumberauth-c0157.firebaseapp.com",
    projectId: "phonenumberauth-c0157",
    storageBucket: "phonenumberauth-c0157.appspot.com",
    messagingSenderId: "757238953656",
    appId: "1:757238953656:web:c645b0beff52b8b798e64d",
    measurementId: "G-YQQP1QHCPB"
  };
  
  const fire =firebase.initializeApp(firebaseConfig)
  export default fire;